package com.pattern.ObserverPattern;

public interface DisplayElement {
	public void display();
}
