package com.pattern.StrategyPattern;

public interface QuackBehavior {

	public void quack();
}
