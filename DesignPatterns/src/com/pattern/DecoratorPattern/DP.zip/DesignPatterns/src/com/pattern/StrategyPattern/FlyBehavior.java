package com.pattern.StrategyPattern;

public interface FlyBehavior {
	public void fly();
}
