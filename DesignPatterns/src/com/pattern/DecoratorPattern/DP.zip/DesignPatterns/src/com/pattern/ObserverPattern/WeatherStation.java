package com.pattern.ObserverPattern;

public class WeatherStation {
	public static void main(String[] args)
	{
		WeatherData weatherData=new WeatherData();
		CurrentConditionsDisplay currentConditionsDisplay=new CurrentConditionsDisplay(weatherData);
		// Dummy Value feed up 
		weatherData.setMeasurements(80f, 65, 30.4f);
		weatherData.setMeasurements(85f, 75, 10.4f);
		weatherData.setMeasurements(90f, 90, 50.4f);
		
	}

}
